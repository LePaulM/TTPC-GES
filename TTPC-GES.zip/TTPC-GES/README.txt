TTPC-GES - VERSION AUTONOME POUR RECETTE

1. Installez Java 17 ou plus : https://adoptium.net ou https://www.oracle.com/java/
2. Lancez build_fat_jar_100OK.bat pour générer le JAR
3. Double-cliquez sur launch_TTPC-GES.bat pour démarrer

Le fichier de base de données sera généré dans :
C:\Users\<nom>\TTPC-GES\ttpc_ges.db

